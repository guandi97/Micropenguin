Pengu
Open Source Operating System
Based primarily on the MikeOS
Real Mode Assembly


Kernel requires the bootloader!
It is over 512 bytes long. 